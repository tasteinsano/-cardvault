# CardVault iPhone Starter

This is a native SwiftUI starter project source for CardVault.

Features included:
- Native iPhone camera capture
- Vision OCR to read card text
- Scryfall fuzzy card lookup
- Current USD price returned by the card data source
- Collection storage in memory for this starter
- Collection, deck, and search screens
- Purple/black CardVault visual direction

## Create the Xcode project
1. On a Mac, install the current Xcode from the Mac App Store.
2. Create an iOS App project named `CardVault`, using SwiftUI and Swift.
3. Replace the generated Swift files with the files in this folder.
4. Add `NSCameraUsageDescription` to the target's Info settings using the text in Info.plist.
5. Choose your iPhone as the run destination and Run.

For a production release, add persistent storage (SwiftData), stronger card-image matching, printing/set disambiguation, price-source terms/compliance, deck-format rules, and App Store assets/signing.
